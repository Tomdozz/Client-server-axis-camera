/**
 * Created by Johan Groth on 2013-12-11.
 */

/**
 *
 * @param element
 * @returns {boolean}
 */
function isElementInViewport(element) {
    var rectangle = element.getBoundingClientRect();

    return (
        rectangle.top >= 0 &&
            rectangle.left >= 0 &&
            rectangle.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rectangle.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
}

/**
 *
 * @param $elements
 * @returns {Function}
 */
function trackElementsForVisibilityChanges($elements) {
    var previousElement = null;

    return function () {
        $elements.each(function () {
            var element = $(this).context;
            if (isElementInViewport(element)) {
                if (previousElement !== element) {
                    var id = $(this).attr('id');

                    previousElement = element;
                    $(document).trigger('scrolledinview', id);
                }

                return false;
            }

            return true;
        });
    }
}